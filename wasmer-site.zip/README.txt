STUDIO SHIN - 部署说明 (Vercel / Wasmer / 其他免费主机)
=======================================================
文件 (全部放在项目根目录):
  app.py            后台 (Flask)  - 文件名必须是 app.py
  index.html        网页
  requirements.txt  依赖 (flask)

脚本保存在哪里 (自动判断):
  有 Redis 环境变量  -> 存到 Upstash Redis   (推荐, Vercel 必须用这个)
  没有               -> 存到文件 /data       (需要主机有持久存储盘, 如 Wasmer volumes)

======== 方案 A: Vercel + Upstash Redis (推荐) ========
1. 把 app.py / index.html / requirements.txt 放进 GitHub 仓库根目录.
2. Vercel 里导入这个仓库 (会自动识别 Flask).
3. Vercel 项目 -> Storage (或 Marketplace) -> 添加 "Upstash for Redis" -> 建一个免费数据库 -> 连接到这个项目.
   连接后 Vercel 会自动加上 KV_REST_API_URL / KV_REST_API_TOKEN (或 UPSTASH_REDIS_REST_URL / _TOKEN), 不用手动填.
4. Settings -> Environment Variables 添加:
     ADMIN_USER = StudShin
     ADMIN_PASS = 你的新密码
     SECRET     = 一长串随机字符
5. 重新部署 (环境变量只对新的部署生效, 一定要 Redeploy).
6. 打开 https://你的网址/api/health 要看到:
     "storage": "redis"   "storage_ok": true   "admin_pass_set": true

======== 方案 B: Wasmer ========
 B1 (也用 Redis): 在 Wasmer 后台加同样的环境变量:
     UPSTASH_REDIS_REST_URL / UPSTASH_REDIS_REST_TOKEN (在 Upstash 控制台复制) + ADMIN_USER / ADMIN_PASS / SECRET
 B2 (用存储盘): 按 app.yaml.example 加 volumes, 看 /api/health 里 "storage": "file", "storage_ok": true.

======== 用法 ========
打开网站 -> Ctrl+Shift+R -> 右上角 "登录" -> 看到绿色 "已连接服务器" -> 添加脚本 -> 刷新还在.

注意:
- 如果保存时报 "CERTIFICATE_VERIFY_FAILED": 确认 requirements.txt 里有 certifi 并重新部署. (最后手段才用 REDIS_SSL_VERIFY=0, 不安全, 不推荐)
- Upstash 免费额度有限制, 每次有人打开网页会读取一次. 个人展示网站一般够用.
- 所有脚本加起来大约不能超过 900KB.
- 不要把密码写进文件, 只放在主机后台的环境变量里.
